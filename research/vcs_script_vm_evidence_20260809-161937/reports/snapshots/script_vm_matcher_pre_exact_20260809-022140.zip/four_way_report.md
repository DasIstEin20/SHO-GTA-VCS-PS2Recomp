# Four-way Script VM semantic matches

Scope: `reLCS -> LCS Android -> LCS PSP -> VCS PSP`. This is an evidence report, not an automatic rename list.

| Role / source anchor | reLCS | LCS Android | LCS PSP | VCS PSP | Score | Status |
| --- | --- | --- | --- | --- | ---: | --- |
| `running_scheduler` / `CRunningScript::Process` | `0x1005eaf0` | `0x002c241c` | `0x000b6290` | `0x0006e848` | 0.9022 | review |
| `script_loader` / `CTheScripts::Init` | `0x10070910` | `0x002845ac` | `0x002a0070` | `0x00139eb8` | 0.8856 | review |
| `parameter_encode` / `CRunningScript::StoreParameters` | `0x10085fb3` | `0x003582bc` | `0x0007f2f4` | `0x002b90f0` | 0.8840 | review |
| `opcode_dispatcher` / `CRunningScript::ProcessOneCommand` | `0x10086d48` | `0x00430878` | `0x001fd910` | `0x001e3bc4` | 0.8815 | review |
| `global_scheduler` / `CTheScripts::Process` | `0x1009313c` | `0x0050b4e8` | `0x002a0474` | `0x0023b474` | 0.8794 | review |
| `parameter_decode` / `CRunningScript::CollectNextParameterWithoutIncreasingPC` | `0x1009d871` | `0x00444548` | `0x00208de0` | `0x00261d2c` | 0.8746 | review |
| `script_spawn` / `CTheScripts::StartNewScript` | `0x100571a0` | `0x00364038` | `0x00132eb8` | `0x001caf5c` | 0.8685 | review |
| `command_partition` / `CRunningScript::ProcessCommands0To99` | `0x10073560` | `0x00482340` | `0x001c569c` | `0x00090b04` | 0.8598 | review |
| `bytecode_reader` / `CTheScripts::Read1ByteFromScript` | `0x1006e521` | `0x00657fac` | `0x00108414` | `0x000ddaac` | 0.8325 | review |

## Interpretation

- `high`: strong and separated candidate; still inspect before renaming.
- `medium`: plausible semantic chain; inspect decompilation and call graph.
- `review`: a bounded candidate with insufficient separation; do not apply as a label.

The score combines normalized p-code (42%), control-flow/data-access shape (28%), constant buckets (10%), string context (8%) and Script VM role affinity (12%).
