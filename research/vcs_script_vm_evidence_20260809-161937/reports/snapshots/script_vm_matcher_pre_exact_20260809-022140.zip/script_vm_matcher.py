#!/usr/bin/env python3
"""Conservative semantic matcher for the GTA Script VM family.

Only Python's standard library is used so a clean workstation can run the
matcher after Ghidra has produced the compact function exports.
"""

from __future__ import annotations

import argparse
import bisect
import csv
import hashlib
import json
import math
import re
import sys
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from statistics import median
from typing import Any, Iterable


CHAIN = ("relcs", "lcs_android", "lcs_psp", "vcs_psp")
ROLE_ORDER = (
    "opcode_dispatcher",
    "command_partition",
    "parameter_decode",
    "parameter_encode",
    "variable_access",
    "bytecode_reader",
    "running_scheduler",
    "global_scheduler",
    "script_loader",
    "script_spawn",
)

# Target percentile, tolerance and weight.  The profiles are deliberately broad:
# they select a Script VM workset without pretending layout alone identifies a
# function. Cross-platform p-code similarity decides the actual chain.
ROLE_PROFILES: dict[str, dict[str, tuple[float, float, float]]] = {
    "opcode_dispatcher": {
        "size": (0.98, 0.20, 1.2), "blocks": (0.97, 0.22, 1.3),
        "cbranch": (0.92, 0.28, 1.2), "calls": (0.73, 0.32, 0.8),
    },
    "command_partition": {
        "size": (0.88, 0.27, 1.0), "blocks": (0.88, 0.27, 1.2),
        "cbranch": (0.85, 0.30, 1.2), "calls": (0.58, 0.36, 0.6),
    },
    "parameter_decode": {
        "size": (0.55, 0.36, 0.9), "blocks": (0.59, 0.36, 1.0),
        "load_store": (0.78, 0.30, 1.3), "cbranch": (0.67, 0.35, 1.0),
        "calls": (0.22, 0.35, 0.5),
    },
    "parameter_encode": {
        "size": (0.46, 0.36, 0.9), "blocks": (0.50, 0.38, 1.0),
        "load_store": (0.80, 0.30, 1.4), "cbranch": (0.60, 0.38, 0.9),
        "calls": (0.18, 0.34, 0.5),
    },
    "variable_access": {
        "size": (0.25, 0.35, 0.8), "blocks": (0.25, 0.37, 0.7),
        "load_store": (0.80, 0.33, 1.2), "calls": (0.10, 0.30, 0.8),
    },
    "bytecode_reader": {
        "size": (0.12, 0.28, 1.1), "blocks": (0.12, 0.30, 0.8),
        "load_store": (0.74, 0.38, 1.2), "calls": (0.03, 0.23, 1.0),
    },
    "running_scheduler": {
        "size": (0.72, 0.33, 1.0), "blocks": (0.70, 0.34, 1.0),
        "calls": (0.65, 0.35, 1.2), "cbranch": (0.65, 0.36, 0.8),
    },
    "global_scheduler": {
        "size": (0.63, 0.36, 0.9), "blocks": (0.58, 0.38, 0.9),
        "calls": (0.78, 0.30, 1.4), "cbranch": (0.50, 0.42, 0.5),
    },
    "script_loader": {
        "size": (0.55, 0.40, 0.8), "blocks": (0.50, 0.42, 0.7),
        "calls": (0.70, 0.34, 1.2), "load_store": (0.66, 0.42, 0.7),
    },
    "script_spawn": {
        "size": (0.36, 0.38, 0.8), "blocks": (0.35, 0.39, 0.8),
        "calls": (0.45, 0.42, 0.7), "load_store": (0.60, 0.42, 0.8),
    },
}


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def json_dump(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def path_record(value: str | Path) -> dict[str, Any]:
    path = Path(value)
    record: dict[str, Any] = {"path": str(path), "exists": path.exists()}
    if not path.exists():
        return record
    record["kind"] = "directory" if path.is_dir() else "file"
    if path.is_file():
        record["size"] = path.stat().st_size
        record["sha256"] = sha256(path)
    else:
        record["files"] = sum(1 for child in path.rglob("*") if child.is_file())
    return record


def normalize_tokens(values: Iterable[str]) -> set[str]:
    stop = {
        "the", "and", "for", "with", "from", "this", "that", "data", "func",
        "function", "undefined", "local", "global", "script", "scripts", "return",
    }
    output: set[str] = set()
    for value in values:
        output.update(token for token in re.findall(r"[a-z][a-z0-9_]{2,}", value.lower()) if token not in stop)
    return output


def source_role(owner: str, name: str) -> str | None:
    qualified = f"{owner}::{name}"
    if qualified == "CRunningScript::ProcessOneCommand":
        return "opcode_dispatcher"
    if owner == "CRunningScript" and name.startswith("ProcessCommands"):
        return "command_partition"
    if qualified in {"CRunningScript::CollectParameters", "CRunningScript::CollectNextParameterWithoutIncreasingPC"}:
        return "parameter_decode"
    if qualified == "CRunningScript::StoreParameters":
        return "parameter_encode"
    if name.startswith("GetPointerToScriptVariable") or name.startswith("GetPointerToLocal"):
        return "variable_access"
    if owner == "CTheScripts" and name.startswith("Read") and name.endswith("FromScript"):
        return "bytecode_reader"
    if qualified == "CRunningScript::Process":
        return "running_scheduler"
    if qualified == "CTheScripts::Process":
        return "global_scheduler"
    if qualified in {"CTheScripts::Init", "CTheScripts::OpenScript", "CTheScripts::ReadMultiScriptFileOffsetsFromScript"}:
        return "script_loader"
    if qualified in {"CTheScripts::StartNewScript", "CTheScripts::StartTestScript"}:
        return "script_spawn"
    return None


METHOD_RE = re.compile(
    r"(?m)^[ \t]*(?:[A-Za-z_][A-Za-z0-9_:<>,*& \t]*?)\s+(?P<owner>CTheScripts|CRunningScript)::(?P<name>[A-Za-z_]\w*)\s*\([^;{}()]*\)\s*(?:const\s*)?\{"
)
INLINE_READER_RE = re.compile(
    r"(?m)^\s*static\s+[^\n;{}]*?\b(?P<name>Read\w*FromScript)\s*\([^;{}]*\)\s*\{"
)


def brace_end(text: str, opening: int) -> int:
    level = 0
    in_string = False
    quote = ""
    escaped = False
    for index in range(opening, len(text)):
        char = text[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                in_string = False
            continue
        if char in {"'", '"'}:
            in_string, quote = True, char
        elif char == "{":
            level += 1
        elif char == "}":
            level -= 1
            if level == 0:
                return index + 1
    return len(text)


def extract_source_semantics(root: Path) -> dict[str, Any]:
    control = root / "src" / "control"
    files = sorted(control.glob("Script*.cpp"))
    if not files:
        raise FileNotFoundError(f"No Script*.cpp source files under {control}")
    functions: list[dict[str, Any]] = []
    for file in files:
        text = file.read_text(encoding="utf-8", errors="replace")
        for match in METHOD_RE.finditer(text):
            body_start = text.find("{", match.start(), match.end())
            body = text[body_start:brace_end(text, body_start)]
            role = source_role(match.group("owner"), match.group("name"))
            if role is None:
                continue
            calls = sorted(set(re.findall(r"\b(?:CTheScripts|CRunningScript)::([A-Za-z_]\w*)\s*\(", body)))
            identifiers = normalize_tokens(re.findall(r"\b[A-Za-z_]\w*\b", body))
            line = text.count("\n", 0, match.start()) + 1
            functions.append({
                "id": f"{match.group('owner')}::{match.group('name')}",
                "owner": match.group("owner"),
                "name": match.group("name"),
                "role": role,
                "file": str(file),
                "line": line,
                "source_lines": body.count("\n") + 1,
                "switches": len(re.findall(r"\bswitch\s*\(", body)),
                "loops": len(re.findall(r"\b(?:for|while|do)\b", body)),
                "calls": calls,
                "tokens": sorted(identifiers),
                "semantic_evidence": sorted(
                    set(token for token in identifiers if token in {
                        "scriptparams", "scriptspace", "m_nip", "m_anlocalvariables",
                        "argument_end", "commands", "mission", "active", "idle", "opcode",
                    })
                ),
            })
    # The fundamental bytecode readers are inline CTheScripts methods in
    # Script.h, so include them explicitly instead of losing this VM layer.
    for header in sorted(control.glob("Script*.h")):
        text = header.read_text(encoding="utf-8", errors="replace")
        for match in INLINE_READER_RE.finditer(text):
            body_start = text.find("{", match.start(), match.end())
            body = text[body_start:brace_end(text, body_start)]
            name = match.group("name")
            role = source_role("CTheScripts", name)
            if role is None:
                continue
            line = text.count("\n", 0, match.start()) + 1
            identifiers = normalize_tokens(re.findall(r"\b[A-Za-z_]\w*\b", body))
            functions.append({
                "id": f"CTheScripts::{name}", "owner": "CTheScripts", "name": name,
                "role": role, "file": str(header), "line": line,
                "source_lines": body.count("\n") + 1, "switches": 0,
                "loops": len(re.findall(r"\b(?:for|while|do)\b", body)), "calls": [],
                "tokens": sorted(identifiers),
                "semantic_evidence": sorted(set(token for token in identifiers if token in {"scriptspace", "pip", "retval"})),
            })
    functions.sort(key=lambda item: (ROLE_ORDER.index(item["role"]), item["id"]))
    anchors = []
    for role in ROLE_ORDER:
        role_functions = [item for item in functions if item["role"] == role]
        # Command pages are deliberately all kept: their ordered family is a
        # useful signature for a dispatcher's call neighborhood.
        anchors.extend(role_functions if role == "command_partition" else role_functions[:2])
    return {
        "schema": 1,
        "generated_at": utc_now(),
        "oracle": {
            "kind": "reVC Script VM source proxy",
            "path": str(root),
            "caveat": "Used to describe Script VM semantics; reLCS itself is matched from ReLCS.dll.",
        },
        "functions": functions,
        "anchors": anchors,
        "role_counts": dict(Counter(item["role"] for item in functions)),
    }


def inspect_ps2_evidence(config: dict[str, Any]) -> dict[str, Any]:
    source = config["ps2_evidence"]
    report: dict[str, Any] = {
        "schema": 1,
        "generated_at": utc_now(),
        "scope": "Auxiliary VCS PS2 evidence only; excluded from four-way chain.",
        "inputs": {key: path_record(value) for key, value in source.items()},
    }
    map_path = Path(source["map_csv"])
    if map_path.exists():
        with map_path.open("r", encoding="utf-8-sig", newline="") as handle:
            entries = list(csv.DictReader(handle))
        names = [row.get("Name", "") for row in entries]
        report["map"] = {
            "functions": len(entries),
            "named_functions": sum(1 for name in names if name and not name.startswith("FUN_")),
            "anonymous_functions": sum(1 for name in names if name.startswith("FUN_")),
            "first_address": entries[0].get("Start") if entries else None,
            "last_address": entries[-1].get("End") if entries else None,
        }
    config_path = Path(source["config_toml"])
    if config_path.exists():
        text = config_path.read_text(encoding="utf-8", errors="replace")
        report["recompiler_config"] = {
            "input": re.search(r'^input\s*=\s*"([^"]+)"', text, re.M).group(1) if re.search(r'^input\s*=\s*"([^"]+)"', text, re.M) else None,
            "output": re.search(r'^output\s*=\s*"([^"]+)"', text, re.M).group(1) if re.search(r'^output\s*=\s*"([^"]+)"', text, re.M) else None,
            "patch_syscalls": re.search(r"^patch_syscalls\s*=\s*(\w+)", text, re.M).group(1) if re.search(r"^patch_syscalls\s*=\s*(\w+)", text, re.M) else None,
        }
    return report


def number(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def pcode_counter(function: dict[str, Any]) -> Counter[str]:
    return Counter({str(key): number(value) for key, value in function.get("pcode", {}).items() if number(value) > 0})


def counter_cosine(left: Counter[str], right: Counter[str]) -> float:
    if not left or not right:
        return 0.0
    numerator = sum(left[key] * right.get(key, 0.0) for key in left)
    left_norm = math.sqrt(sum(value * value for value in left.values()))
    right_norm = math.sqrt(sum(value * value for value in right.values()))
    return numerator / (left_norm * right_norm) if left_norm and right_norm else 0.0


def close(left: float, right: float, scale: float = 1.0) -> float:
    return math.exp(-abs(left - right) / max(scale, 1e-9))


def feature_values(function: dict[str, Any]) -> dict[str, float]:
    pcode = max(number(function.get("pcode_count")), 1.0)
    instructions = max(number(function.get("instructions")), 1.0)
    return {
        "size": math.log1p(max(number(function.get("size")), instructions)),
        "blocks": math.log1p(number(function.get("basic_blocks"))),
        "calls": math.log1p(number(function.get("call_ops"))),
        "branch": number(function.get("branch_ops")) / pcode,
        "cbranch": number(function.get("cbranch_ops")) / pcode,
        "load_store": (number(function.get("load_ops")) + number(function.get("store_ops"))) / pcode,
        "pcode_density": pcode / instructions,
    }


def percentile(values: list[float], value: float) -> float:
    if not values:
        return 0.0
    # Columns are sorted once per platform. Binary search keeps candidate-role
    # selection O(log n), which matters for the 13k-function Android export.
    return bisect.bisect_right(values, value) / len(values)


@dataclass
class Population:
    functions: list[dict[str, Any]]
    features: dict[str, dict[str, float]]
    columns: dict[str, list[float]]

    @classmethod
    def create(cls, functions: list[dict[str, Any]]) -> "Population":
        usable = [item for item in functions if number(item.get("instructions")) >= 4 and number(item.get("pcode_count")) >= 4]
        features = {str(item["address"]): feature_values(item) for item in usable}
        columns = {key: sorted(value[key] for value in features.values()) for key in next(iter(features.values()), {}).keys()}
        return cls(usable, features, columns)

    def affinity(self, function: dict[str, Any], role: str) -> float:
        current = self.features.get(str(function.get("address")))
        if current is None:
            return 0.0
        profile = ROLE_PROFILES[role]
        weighted = 0.0
        weights = 0.0
        for key, (target, tolerance, weight) in profile.items():
            rank = percentile(self.columns[key], current[key])
            weighted += max(0.0, 1.0 - abs(rank - target) / tolerance) * weight
            weights += weight
        return weighted / weights if weights else 0.0


def string_similarity(left: dict[str, Any], right: dict[str, Any]) -> float:
    a = normalize_tokens(left.get("strings", []))
    b = normalize_tokens(right.get("strings", []))
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def structural_similarity(left: dict[str, Any], right: dict[str, Any]) -> float:
    a = feature_values(left)
    b = feature_values(right)
    return (
        0.28 * close(a["size"], b["size"], 1.0)
        + 0.22 * close(a["blocks"], b["blocks"], 1.0)
        + 0.16 * close(a["calls"], b["calls"], 1.0)
        + 0.12 * close(a["branch"], b["branch"], 0.08)
        + 0.12 * close(a["cbranch"], b["cbranch"], 0.06)
        + 0.10 * close(a["load_store"], b["load_store"], 0.08)
    )


def semantic_similarity(left: dict[str, Any], right: dict[str, Any], role: str, left_pop: Population, right_pop: Population) -> tuple[float, dict[str, float]]:
    pcode = counter_cosine(pcode_counter(left), pcode_counter(right))
    constants = counter_cosine(
        Counter({str(key): number(value) for key, value in left.get("constant_buckets", {}).items()}),
        Counter({str(key): number(value) for key, value in right.get("constant_buckets", {}).items()}),
    )
    structure = structural_similarity(left, right)
    strings = string_similarity(left, right)
    role_score = (left_pop.affinity(left, role) + right_pop.affinity(right, role)) / 2.0
    score = 0.42 * pcode + 0.28 * structure + 0.10 * constants + 0.08 * strings + 0.12 * role_score
    return score, {
        "pcode": round(pcode, 4), "structure": round(structure, 4),
        "constants": round(constants, 4), "strings": round(strings, 4),
        "role": round(role_score, 4),
    }


def candidates(population: Population, role: str, limit: int = 16) -> list[tuple[dict[str, Any], float]]:
    ranked = sorted(((function, population.affinity(function, role)) for function in population.functions), key=lambda item: (-item[1], str(item[0]["address"])))
    return ranked[:limit]


def nearest(source: dict[str, Any], targets: list[tuple[dict[str, Any], float]], role: str, source_pop: Population, target_pop: Population, limit: int) -> list[tuple[dict[str, Any], float, dict[str, float]]]:
    scored = []
    for target, _ in targets:
        score, evidence = semantic_similarity(source, target, role, source_pop, target_pop)
        scored.append((target, score, evidence))
    return sorted(scored, key=lambda item: (-item[1], str(item[0]["address"])))[:limit]


def brief(function: dict[str, Any]) -> dict[str, Any]:
    return {
        "address": function.get("address"), "name": function.get("name"),
        "namespace": function.get("namespace"), "size": function.get("size"),
        "instructions": function.get("instructions"), "basic_blocks": function.get("basic_blocks"),
        "call_ops": function.get("call_ops"), "branch_ops": function.get("branch_ops"),
        "cbranch_ops": function.get("cbranch_ops"), "load_ops": function.get("load_ops"),
        "store_ops": function.get("store_ops"), "top_pcode": dict(pcode_counter(function).most_common(8)),
        "strings": function.get("strings", [])[:5], "callees": function.get("callees", [])[:8],
    }


def chain_for_anchor(anchor: dict[str, Any], populations: dict[str, Population]) -> list[dict[str, Any]]:
    role = anchor["role"]
    sets = {label: candidates(populations[label], role) for label in CHAIN}
    beams: list[tuple[list[dict[str, Any]], list[float], list[dict[str, float]], float]] = []
    for first, first_affinity in sets["relcs"][:8]:
        for second, score, evidence in nearest(first, sets["lcs_android"], role, populations["relcs"], populations["lcs_android"], 5):
            seed = math.sqrt(max(first_affinity, 0.01) * max(score, 0.01))
            beams.append(([first, second], [score], [evidence], seed))
    beams.sort(key=lambda item: -item[3])
    beams = beams[:28]
    for next_label, previous_label in (("lcs_psp", "lcs_android"), ("vcs_psp", "lcs_psp")):
        expanded: list[tuple[list[dict[str, Any]], list[float], list[dict[str, float]], float]] = []
        for functions, scores, evidence, seed in beams:
            for target, score, detail in nearest(functions[-1], sets[next_label], role, populations[previous_label], populations[next_label], 4):
                expanded.append((functions + [target], scores + [score], evidence + [detail], seed * max(score, 0.01)))
        expanded.sort(key=lambda item: -item[3])
        beams = expanded[:32]
    result = []
    for functions, scores, evidence, product in beams:
        overall = product ** (1.0 / 4.0)
        result.append({
            "role": role,
            "source_anchor": {key: anchor.get(key) for key in ("id", "file", "line", "semantic_evidence", "source_lines")},
            "platforms": {label: brief(function) for label, function in zip(CHAIN, functions)},
            "bootstrap_affinity": round(populations["relcs"].affinity(functions[0], role), 4),
            "edge_scores": [round(score, 4) for score in scores],
            "edge_evidence": evidence,
            "score": round(overall, 4),
        })
    return result


def classify(score: float, margin: float) -> str:
    if score >= 0.82 and margin >= 0.10:
        return "high"
    if score >= 0.68 and margin >= 0.05:
        return "medium"
    if score >= 0.46:
        return "review"
    return "abstain"


def match(source: dict[str, Any], exports: dict[str, dict[str, Any]]) -> dict[str, Any]:
    populations = {label: Population.create(exports[label].get("functions", [])) for label in CHAIN}
    all_options: list[dict[str, Any]] = []
    anchors = [item for item in source.get("anchors", []) if item.get("role") in ROLE_PROFILES]
    for anchor in anchors:
        chains = chain_for_anchor(anchor, populations)
        if not chains:
            continue
        best = chains[0]
        runner = chains[1]["score"] if len(chains) > 1 else 0.0
        best["runner_up_score"] = round(runner, 4)
        best["margin"] = round(best["score"] - runner, 4)
        best["classification"] = classify(best["score"], best["margin"])
        best["alternatives"] = [
            {"score": item["score"], "relcs": item["platforms"]["relcs"]["address"], "vcs_psp": item["platforms"]["vcs_psp"]["address"]}
            for item in chains[1:4]
        ]
        all_options.append(best)

    # A Script VM role should map to a distinct function per target. Keep the
    # highest-scored chain, but retain conflicts for transparent manual review.
    used: dict[str, set[str]] = {label: set() for label in CHAIN}
    accepted: list[dict[str, Any]] = []
    conflicts: list[dict[str, Any]] = []
    for item in sorted(all_options, key=lambda value: (-value["score"], value["source_anchor"]["id"])):
        addresses = {label: str(item["platforms"][label]["address"]) for label in CHAIN}
        if any(addresses[label] in used[label] for label in CHAIN):
            conflicts.append(item)
            continue
        for label in CHAIN:
            used[label].add(addresses[label])
        accepted.append(item)
    return {
        "schema": 1,
        "generated_at": utc_now(),
        "scope": "Script VM only",
        "chain": list(CHAIN),
        "method": {
            "pcode_weight": 0.42, "structure_weight": 0.28,
            "constant_weight": 0.10, "string_weight": 0.08, "role_weight": 0.12,
            "policy": "conservative bounded semantic beam search; low-margin chains are review-only",
        },
        "inputs": {
            label: {
                "program": exports[label].get("program"), "sha256": exports[label].get("sha256"),
                "language": exports[label].get("language"), "functions": len(populations[label].functions),
            }
            for label in CHAIN
        },
        "matches": accepted,
        "conflicts": conflicts,
    }


def report_markdown(result: dict[str, Any]) -> str:
    lines = [
        "# Four-way Script VM semantic matches", "",
        "Scope: `reLCS -> LCS Android -> LCS PSP -> VCS PSP`. This is an evidence report, not an automatic rename list.", "",
        "| Role / source anchor | reLCS | LCS Android | LCS PSP | VCS PSP | Score | Status |",
        "| --- | --- | --- | --- | --- | ---: | --- |",
    ]
    for item in result["matches"]:
        values = [item["platforms"][label]["address"] for label in CHAIN]
        lines.append(
            f"| `{item['role']}` / `{item['source_anchor']['id']}` | "
            f"`{values[0]}` | `{values[1]}` | `{values[2]}` | `{values[3]}` | "
            f"{item['score']:.4f} | {item['classification']} |"
        )
    if not result["matches"]:
        lines.append("| No eligible Script VM chains | — | — | — | — | — | abstain |")
    lines += ["", "## Interpretation", "", "- `high`: strong and separated candidate; still inspect before renaming.", "- `medium`: plausible semantic chain; inspect decompilation and call graph.", "- `review`: a bounded candidate with insufficient separation; do not apply as a label.", "", "The score combines normalized p-code (42%), control-flow/data-access shape (28%), constant buckets (10%), string context (8%) and Script VM role affinity (12%)."]
    return "\n".join(lines) + "\n"


def write_agent_context(result: dict[str, Any], output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    context = {
        "schema": 1,
        "generated_at": result["generated_at"],
        "scope": result["scope"],
        "chain": result["chain"],
        "instructions": [
            "Treat review entries as candidate addresses, not labels.",
            "Validate caller/callee topology and decompiler output before naming a function.",
            "Keep work inside Script VM until a correspondence is manually confirmed.",
        ],
        "matches": [
            {
                "role": item["role"], "source_anchor": item["source_anchor"], "score": item["score"],
                "margin": item["margin"], "classification": item["classification"],
                "addresses": {label: item["platforms"][label]["address"] for label in CHAIN},
                "evidence": item["edge_evidence"],
            }
            for item in result["matches"]
        ],
    }
    json_dump(output / "script_vm_context.json", context)
    lines = ["# Generated Script VM context", "", "This file is generated by `script_vm_matcher`; do not edit it.", ""]
    for match_item in context["matches"]:
        addresses = " | ".join(f"{label}: `{address}`" for label, address in match_item["addresses"].items())
        lines += [f"## {match_item['role']} — {match_item['classification']} ({match_item['score']:.4f})", "", addresses, ""]
    (output / "script_vm_context.md").write_text("\n".join(lines), encoding="utf-8")


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return value


def command_source(args: argparse.Namespace) -> int:
    config = load_json(Path(args.config))
    output = Path(args.output)
    json_dump(output, extract_source_semantics(Path(config["revc_source"])))
    print(f"Wrote source semantics: {output}")
    return 0


def command_ps2(args: argparse.Namespace) -> int:
    config = load_json(Path(args.config))
    output = Path(args.output)
    json_dump(output, inspect_ps2_evidence(config))
    print(f"Wrote PS2 evidence: {output}")
    return 0


def command_match(args: argparse.Namespace) -> int:
    source = load_json(Path(args.source))
    exports = {label: load_json(Path(getattr(args, label))) for label in CHAIN}
    missing = [label for label, export in exports.items() if export.get("schema") != 1 or not isinstance(export.get("functions"), list)]
    if missing:
        raise ValueError(f"Invalid or unsupported Ghidra export(s): {', '.join(missing)}")
    output_dir = Path(args.output_dir)
    result = match(source, exports)
    json_dump(output_dir / "four_way_matches.json", result)
    (output_dir / "four_way_report.md").parent.mkdir(parents=True, exist_ok=True)
    (output_dir / "four_way_report.md").write_text(report_markdown(result), encoding="utf-8")
    write_agent_context(result, Path(args.agents_dir))
    print(f"Wrote {len(result['matches'])} Script VM chains to {output_dir}")
    return 0


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    commands = value.add_subparsers(required=True)
    source = commands.add_parser("source", help="derive Script VM anchors from reVC source")
    source.add_argument("--config", required=True)
    source.add_argument("--output", required=True)
    source.set_defaults(func=command_source)
    ps2 = commands.add_parser("ps2-evidence", help="record supplied VCS PS2 auxiliary evidence")
    ps2.add_argument("--config", required=True)
    ps2.add_argument("--output", required=True)
    ps2.set_defaults(func=command_ps2)
    matcher = commands.add_parser("match", help="build the four-way Script VM candidate chain")
    matcher.add_argument("--source", required=True)
    for label in CHAIN:
        matcher.add_argument(f"--{label}", required=True)
    matcher.add_argument("--output-dir", required=True)
    matcher.add_argument("--agents-dir", required=True)
    matcher.set_defaults(func=command_match)
    return value


def main() -> int:
    try:
        args = parser().parse_args()
        return args.func(args)
    except (FileNotFoundError, ValueError, json.JSONDecodeError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
