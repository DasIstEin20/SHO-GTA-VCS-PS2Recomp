# Four-way Script VM semantic matcher

This directory contains a conservative, reproducible matcher for the GTA Script
VM family:

`reLCS (PC DLL) -> LCS Android -> LCS PSP -> VCS PSP`

It intentionally starts with the Script VM only.  It does not attempt to match
gameplay, rendering, streaming, or audio code.  The result is a set of reviewable
function correspondences, not names injected into any binary.

## Inputs

`config/paths.json` contains the supplied locations.  The four primary binaries
are:

| Label | Artifact |
| --- | --- |
| `relcs` | `ReLCS.dll` in the LCS PC port |
| `lcs_android` | `libGTALcs.so` from the original APK |
| `lcs_psp` | `GTA_LCS_Debug_EBOOT.ELF` |
| `vcs_psp` | `GTA_VCS_Debug_EBOOT.ELF` |

The `reVC` source is used only as a semantic oracle for the Script VM shape. It
is not reported as an LCS binary match. The VCS PS2 map/config/ELF/recompiler
output are collected as auxiliary evidence; they are deliberately not added as a
fifth matching column.

## Run

From this directory:

```powershell
.\run-four-way.ps1
```

The script creates a timestamped Ghidra project under `work/`, exports compact
function fingerprints to `artifacts/exports/`, then builds the four-way report.
The optional PS2 function export is off by default because it is expensive. The
PS2 map, config, ELF, and decompiler-output inventory are always recorded.

```powershell
.\run-four-way.ps1 -IncludePs2Export
```

No binary is altered. Ghidra projects and JSON/Markdown reports are written only
inside this directory.

## Outputs

- `artifacts/source_semantics.json` — Script VM roles derived from `reVC`.
- `artifacts/ps2_evidence.json` — integrity and coverage metadata for the VCS
  PS2 inputs.
- `artifacts/four_way_matches.json` — machine-readable chain of candidates.
- `artifacts/four_way_report.md` — concise human review report.
- `../agents/generated/script_vm_context.json` and `.md` — agent-ready context
  based on the generated semantic result.

Every match contains a score, runner-up margin, classification and the measured
evidence. `high` is intentionally rare; use `review` rows for Ghidra validation
before renaming functions.

## Matcher design

Ghidra exports architecture-neutral p-code histograms, basic-block/control-flow
shape, call fan-out, string-token context and constant buckets. Candidate
selection starts from Script VM roles learned from the source oracle (dispatcher,
parameter codec, scheduler, loader, spawn, command partitions and helpers).
The matcher then performs a bounded semantic beam search through the requested
four-way order. A function can only appear once in a final chain.

The tool abstains rather than inventing a name: low-margin chains are emitted as
`review`, never as confirmed equivalences.
