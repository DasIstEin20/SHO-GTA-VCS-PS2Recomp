// Export compact, architecture-neutral function features for the Script VM matcher.
//@category GTA.ScriptVM
// Usage from analyzeHeadless:
//   -postScript ExportScriptVm.java <absolute-output-json>

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.block.BasicBlockModel;
import ghidra.program.model.block.CodeBlock;
import ghidra.program.model.block.CodeBlockIterator;
import ghidra.program.model.listing.Data;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.listing.Listing;
import ghidra.program.model.listing.Program;
import ghidra.program.model.pcode.PcodeOp;
import ghidra.program.model.pcode.Varnode;
import ghidra.program.model.symbol.Reference;

public class ExportScriptVm extends GhidraScript {

    private static final int MAX_STRINGS = 12;
    private static final int MAX_CALLEES = 64;
    private static final int MAX_CONSTANT_BUCKETS = 16;

    private static String json(String value) {
        if (value == null) return "null";
        StringBuilder out = new StringBuilder(value.length() + 8);
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
            case '\\': out.append("\\\\"); break;
            case '"': out.append("\\\""); break;
            case '\n': out.append("\\n"); break;
            case '\r': out.append("\\r"); break;
            case '\t': out.append("\\t"); break;
            default:
                if (c < 0x20) out.append(String.format("\\u%04x", (int)c));
                else out.append(c);
            }
        }
        out.append('"');
        return out.toString();
    }

    private static String hex(Address address) {
        return address == null ? null : "0x" + address.toString();
    }

    private static int sizeBucket(long value) {
        if (value == 0) return 0;
        if (value <= 2) return 1;
        if (value <= 8) return 2;
        if (value <= 31) return 3;
        if (value <= 255) return 4;
        if (value <= 4095) return 5;
        return 6;
    }

    private static String sha256(File input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        java.io.FileInputStream stream = new java.io.FileInputStream(input);
        byte[] buffer = new byte[1024 * 128];
        int read;
        while ((read = stream.read(buffer)) != -1) digest.update(buffer, 0, read);
        stream.close();
        StringBuilder hex = new StringBuilder();
        for (byte b : digest.digest()) hex.append(String.format("%02x", b));
        return hex.toString();
    }

    private static List<Map.Entry<String, Integer>> top(Map<String, Integer> values, int limit) {
        List<Map.Entry<String, Integer>> entries = new ArrayList<Map.Entry<String, Integer>>(values.entrySet());
        Collections.sort(entries, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                int value = b.getValue().compareTo(a.getValue());
                return value != 0 ? value : a.getKey().compareTo(b.getKey());
            }
        });
        return entries.subList(0, Math.min(limit, entries.size()));
    }

    private static void writeCounter(BufferedWriter writer, Map<String, Integer> values, int limit) throws Exception {
        writer.write("{");
        boolean first = true;
        for (Map.Entry<String, Integer> entry : top(values, limit)) {
            if (!first) writer.write(",");
            writer.write(json(entry.getKey()));
            writer.write(":");
            writer.write(String.valueOf(entry.getValue()));
            first = false;
        }
        writer.write("}");
    }

    private static void writeStringArray(BufferedWriter writer, List<String> entries) throws Exception {
        writer.write("[");
        for (int i = 0; i < entries.size(); i++) {
            if (i > 0) writer.write(",");
            writer.write(json(entries.get(i)));
        }
        writer.write("]");
    }

    private int basicBlockCount(BasicBlockModel model, Function function) throws Exception {
        int count = 0;
        CodeBlockIterator blocks = model.getCodeBlocksContaining(function.getBody(), monitor);
        while (blocks.hasNext()) {
            blocks.next();
            count++;
        }
        return count;
    }

    private String stringAt(Address address, Listing listing) {
        Data data = listing.getDefinedDataContaining(address);
        if (data == null || !data.hasStringValue()) return null;
        String representation = data.getDefaultValueRepresentation();
        if (representation == null) return null;
        representation = representation.replaceAll("^[Lu]?\\\"|\\\"$", "");
        return representation.length() > 160 ? representation.substring(0, 160) : representation;
    }

    private void writeFunction(BufferedWriter writer, Function function, BasicBlockModel blocks,
            Listing listing, Map<Address, String> names) throws Exception {
        long instructionCount = 0;
        long pcodeCount = 0;
        long callCount = 0;
        long branchCount = 0;
        long conditionalBranchCount = 0;
        long loadCount = 0;
        long storeCount = 0;
        Map<String, Integer> pcode = new HashMap<String, Integer>();
        Map<String, Integer> constants = new HashMap<String, Integer>();
        Set<String> stringsSet = new HashSet<String>();
        InstructionIterator instructions = listing.getInstructions(function.getBody(), true);
        while (instructions.hasNext()) {
            Instruction instruction = instructions.next();
            instructionCount++;
            PcodeOp[] ops = instruction.getPcode();
            if (ops != null) for (PcodeOp op : ops) {
                String mnemonic = op.getMnemonic();
                Integer prior = pcode.get(mnemonic);
                pcode.put(mnemonic, prior == null ? 1 : prior + 1);
                pcodeCount++;
                if ("CALL".equals(mnemonic) || "CALLIND".equals(mnemonic)) callCount++;
                if ("BRANCH".equals(mnemonic) || "BRANCHIND".equals(mnemonic) || "CBRANCH".equals(mnemonic)) branchCount++;
                if ("CBRANCH".equals(mnemonic)) conditionalBranchCount++;
                if ("LOAD".equals(mnemonic)) loadCount++;
                if ("STORE".equals(mnemonic)) storeCount++;
                for (int i = 0; i < op.getNumInputs(); i++) {
                    Varnode node = op.getInput(i);
                    if (node != null && node.isConstant()) {
                        String bucket = "b" + sizeBucket(node.getOffset());
                        Integer before = constants.get(bucket);
                        constants.put(bucket, before == null ? 1 : before + 1);
                    }
                }
            }
            Reference[] references = currentProgram.getReferenceManager().getReferencesFrom(instruction.getAddress());
            for (Reference ref : references) {
                if (stringsSet.size() >= MAX_STRINGS) break;
                String value = stringAt(ref.getToAddress(), listing);
                if (value != null && value.length() >= 3) stringsSet.add(value);
            }
        }

        List<String> callees = new ArrayList<String>();
        for (Function called : function.getCalledFunctions(monitor)) {
            String name = names.get(called.getEntryPoint());
            if (name == null) name = called.getName();
            callees.add(hex(called.getEntryPoint()) + ":" + name);
            if (callees.size() >= MAX_CALLEES) break;
        }
        Collections.sort(callees);
        List<String> strings = new ArrayList<String>(stringsSet);
        Collections.sort(strings);

        writer.write("{\"address\":"); writer.write(json(hex(function.getEntryPoint())));
        writer.write(",\"name\":"); writer.write(json(function.getName()));
        writer.write(",\"namespace\":"); writer.write(json(function.getParentNamespace().getName(true)));
        writer.write(",\"size\":"); writer.write(String.valueOf(function.getBody().getNumAddresses()));
        writer.write(",\"instructions\":"); writer.write(String.valueOf(instructionCount));
        writer.write(",\"basic_blocks\":"); writer.write(String.valueOf(basicBlockCount(blocks, function)));
        writer.write(",\"pcode_count\":"); writer.write(String.valueOf(pcodeCount));
        writer.write(",\"call_ops\":"); writer.write(String.valueOf(callCount));
        writer.write(",\"branch_ops\":"); writer.write(String.valueOf(branchCount));
        writer.write(",\"cbranch_ops\":"); writer.write(String.valueOf(conditionalBranchCount));
        writer.write(",\"load_ops\":"); writer.write(String.valueOf(loadCount));
        writer.write(",\"store_ops\":"); writer.write(String.valueOf(storeCount));
        writer.write(",\"pcode\":"); writeCounter(writer, pcode, 64);
        writer.write(",\"constant_buckets\":"); writeCounter(writer, constants, MAX_CONSTANT_BUCKETS);
        writer.write(",\"callees\":"); writeStringArray(writer, callees);
        writer.write(",\"strings\":"); writeStringArray(writer, strings);
        writer.write("}");
    }

    @Override
    public void run() throws Exception {
        String[] args = getScriptArgs();
        if (args.length != 1) {
            printerr("Usage: ExportScriptVm.java <absolute-output-json>");
            return;
        }
        File output = new File(args[0]);
        File parent = output.getParentFile();
        if (parent != null) parent.mkdirs();

        Program program = currentProgram;
        Listing listing = program.getListing();
        Map<Address, String> names = new HashMap<Address, String>();
        FunctionIterator namedFunctions = program.getFunctionManager().getFunctions(true);
        while (namedFunctions.hasNext()) {
            Function f = namedFunctions.next();
            names.put(f.getEntryPoint(), f.getName());
        }

        File executable = new File(program.getExecutablePath());
        String inputHash = executable.exists() ? sha256(executable) : null;
        BasicBlockModel blocks = new BasicBlockModel(program);
        FunctionIterator functions = program.getFunctionManager().getFunctions(true);
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(output), StandardCharsets.UTF_8));
        writer.write("{\"schema\":1,\"program\":"); writer.write(json(program.getName()));
        writer.write(",\"executable_path\":"); writer.write(json(program.getExecutablePath()));
        writer.write(",\"sha256\":"); writer.write(json(inputHash));
        writer.write(",\"language\":"); writer.write(json(program.getLanguageID().toString()));
        writer.write(",\"functions\":[");
        boolean first = true;
        int count = 0;
        while (functions.hasNext()) {
            monitor.checkCancelled();
            Function function = functions.next();
            if (function.isExternal() || function.getBody().isEmpty()) continue;
            if (!first) writer.write(",");
            writeFunction(writer, function, blocks, listing, names);
            first = false;
            count++;
            if ((count % 250) == 0) println("Exported " + count + " functions");
        }
        writer.write("]}");
        writer.close();
        println("Exported " + count + " functions to " + output.getAbsolutePath());
    }
}
