# Script VM four-way matcher — analysis handoff

This package contains the completed first-pass, Script-VM-only semantic match:

`reLCS PC -> LCS Android -> LCS PSP -> VCS PSP`

## Read first

1. `artifacts/four_way_report.md` — compact review table.
2. `agents/generated/script_vm_context.md` — agent-oriented context.
3. `artifacts/four_way_matches.json` — full scores, runner-up margins and
   evidence per edge.

All rows are **review candidates**, not confirmed labels. The score combines
normalized Ghidra p-code (42%), CFG/data-access shape (28%), constant buckets
(10%), string context (8%), and a Script-VM role profile (12%). A low
runner-up margin intentionally prevents automatic naming.

## Included evidence

- `artifacts/source_semantics.json`: Script VM roles inferred from the supplied
  reVC source: dispatcher, command pages, parameter codecs, ScriptSpace readers,
  scheduler, loader, and spawner.
- `artifacts/exports/*.json`: complete compact Ghidra exports for the four
  matched binaries. They contain only function-level metadata, p-code counters,
  control-flow shape, callees, limited strings, and constant buckets.
- `artifacts/ps2_evidence.json`: supplied VCS PS2 map/config/ELF/recompiler
  inventory. PS2 is corroborating evidence only; it is deliberately not a fifth
  matching column.
- `agents/`: instructions and generated context for a subsequent analysis pass.

No game binary, ISO, APK/OBB, Ghidra project database, source tree, or emulator
is packaged. Absolute paths inside the original Ghidra exports identify the
analysed artifacts but are not required to read the semantic result.
