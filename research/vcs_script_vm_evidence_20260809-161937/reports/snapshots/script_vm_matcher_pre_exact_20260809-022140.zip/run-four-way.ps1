[CmdletBinding()]
param(
    [switch]$IncludePs2Export,
    [string]$Config = (Join-Path $PSScriptRoot 'config\paths.json')
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$python = 'python'
$matcher = Join-Path $root 'src\script_vm_matcher.py'
$artifacts = Join-Path $root 'artifacts'
$exports = Join-Path $artifacts 'exports'
$agents = Join-Path (Split-Path $root -Parent) 'agents\generated'
$cfg = Get-Content -LiteralPath $Config -Raw | ConvertFrom-Json

New-Item -ItemType Directory -Force -Path $artifacts, $exports, $agents | Out-Null
& $python $matcher source --config $Config --output (Join-Path $artifacts 'source_semantics.json')
& $python $matcher ps2-evidence --config $Config --output (Join-Path $artifacts 'ps2_evidence.json')

$ghidra = Join-Path $cfg.ghidra_home 'support\analyzeHeadless.bat'
if (-not (Test-Path -LiteralPath $ghidra)) { throw "Ghidra launcher missing: $ghidra" }
$scriptPath = Join-Path $root 'ghidra'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$projectRoot = Join-Path $root "work\ghidra-$stamp"
$ghidraUserRoot = Join-Path $root 'work\ghidra-user'
New-Item -ItemType Directory -Force -Path $projectRoot, $ghidraUserRoot | Out-Null
# This installation also has the Emotion Engine extension in the normal roaming
# profile. Keep headless runs isolated so that the local extension is loaded once.
$env:USERPROFILE = $ghidraUserRoot
$env:APPDATA = Join-Path $ghidraUserRoot 'AppData\Roaming'
$env:LOCALAPPDATA = Join-Path $ghidraUserRoot 'AppData\Local'

function Export-GhidraFeatures([string]$Label, [string]$BinaryPath) {
    if (-not (Test-Path -LiteralPath $BinaryPath)) { throw "Missing $Label binary: $BinaryPath" }
    $out = Join-Path $exports "$Label.json"
    & $ghidra $projectRoot "scriptvm_$Label" -import $BinaryPath -scriptPath $scriptPath -postScript ExportScriptVm.java $out -analysisTimeoutPerFile 1800
    if (-not (Test-Path -LiteralPath $out)) { throw "Ghidra did not create export for $Label" }
}

Export-GhidraFeatures 'relcs' $cfg.binaries.relcs
Export-GhidraFeatures 'lcs_android' $cfg.binaries.lcs_android
Export-GhidraFeatures 'lcs_psp' $cfg.binaries.lcs_psp
Export-GhidraFeatures 'vcs_psp' $cfg.binaries.vcs_psp

if ($IncludePs2Export) {
    Export-GhidraFeatures 'vcs_ps2_auxiliary' $cfg.ps2_evidence.elf
}

& $python $matcher match `
    --source (Join-Path $artifacts 'source_semantics.json') `
    --relcs (Join-Path $exports 'relcs.json') `
    --lcs_android (Join-Path $exports 'lcs_android.json') `
    --lcs_psp (Join-Path $exports 'lcs_psp.json') `
    --vcs_psp (Join-Path $exports 'vcs_psp.json') `
    --output-dir $artifacts `
    --agents-dir $agents

Write-Host "Completed. Review $(Join-Path $artifacts 'four_way_report.md') and $(Join-Path $agents 'script_vm_context.md')."
