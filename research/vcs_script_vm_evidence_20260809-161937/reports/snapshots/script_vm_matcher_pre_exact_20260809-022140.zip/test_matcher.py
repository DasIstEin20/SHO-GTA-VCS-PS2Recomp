import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import script_vm_matcher as matcher


def fixture(address, scale=1.0):
    return {
        "address": address,
        "name": "FUN_" + address[2:],
        "namespace": "Global",
        "size": int(800 * scale),
        "instructions": int(220 * scale),
        "basic_blocks": int(35 * scale),
        "pcode_count": int(620 * scale),
        "call_ops": int(30 * scale),
        "branch_ops": int(80 * scale),
        "cbranch_ops": int(58 * scale),
        "load_ops": int(55 * scale),
        "store_ops": int(32 * scale),
        "pcode": {"COPY": 100, "INT_ADD": 80, "LOAD": 55, "STORE": 32, "CBRANCH": 58, "CALL": 30},
        "constant_buckets": {"b1": 24, "b2": 40, "b4": 10},
        "callees": [],
        "strings": ["MISSION", "SCRIPT"],
    }


class SourceTests(unittest.TestCase):
    def test_extracts_cpp_and_inline_reader_anchors(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            control = root / "src" / "control"
            control.mkdir(parents=True)
            (control / "Script.cpp").write_text(
                "void CRunningScript::ProcessOneCommand() { switch (x) { case 1: break; } }\n"
                "void CRunningScript::CollectParameters() { switch (CTheScripts::Read1ByteFromScript(x)) { case 1: break; } }\n"
                "void CTheScripts::Process() { CRunningScript::ProcessOneCommand(); }\n",
                encoding="utf-8",
            )
            (control / "Script.h").write_text(
                "static int Read1ByteFromScript(int x) { return ScriptSpace[x]; }\n", encoding="utf-8"
            )
            result = matcher.extract_source_semantics(root)
            roles = {item["role"] for item in result["anchors"]}
            self.assertIn("opcode_dispatcher", roles)
            self.assertIn("parameter_decode", roles)
            self.assertIn("global_scheduler", roles)
            self.assertIn("bytecode_reader", roles)


class MatchTests(unittest.TestCase):
    def test_chain_keeps_four_platforms_and_evidence(self):
        source = {
            "anchors": [{"id": "CRunningScript::ProcessOneCommand", "role": "opcode_dispatcher", "file": "Script.cpp", "line": 1, "semantic_evidence": [], "source_lines": 10}],
        }
        exports = {
            label: {"schema": 1, "program": label, "sha256": label, "language": "test", "functions": [fixture("0x1000", 1.0), fixture("0x2000", 0.2)]}
            for label in matcher.CHAIN
        }
        result = matcher.match(source, exports)
        self.assertEqual(result["chain"], list(matcher.CHAIN))
        self.assertGreaterEqual(len(result["matches"]), 1)
        item = result["matches"][0]
        self.assertEqual(set(item["platforms"]), set(matcher.CHAIN))
        self.assertEqual(len(item["edge_evidence"]), 3)
        self.assertIn(item["classification"], {"high", "medium", "review", "abstain"})


if __name__ == "__main__":
    unittest.main()
